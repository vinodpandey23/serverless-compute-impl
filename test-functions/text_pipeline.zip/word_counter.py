from collections import Counter

def count_words(keywords):
    return Counter(keywords)
